package com.example.zakonstrolno;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{

    Button redBtn;
    Button yellowBtn;
    Button greenBtn;
    Button startBtn;
    Button resetBtn;
    Button stopBtn;
    boolean isWorking;
    boolean isStopped;
    boolean isReset;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        redBtn = (Button) findViewById(R.id.redBtn);
        yellowBtn = (Button) findViewById(R.id.yellowBtn);
        greenBtn = (Button) findViewById(R.id.greenBtn);
        startBtn = (Button) findViewById(R.id.startBtn);
        resetBtn = (Button) findViewById(R.id.resetBtn);
        stopBtn = (Button) findViewById(R.id.stopBtn);

        redBtn.setBackgroundColor(Color.RED);
        yellowBtn.setBackgroundColor(Color.GRAY);
        greenBtn.setBackgroundColor(Color.GRAY);

        isWorking = false;
        isStopped = false;
        isReset = false;

        startBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               if(!isWorking)
               {
                   startTrafficLight();
                   isWorking = true;
               }

               isStopped = false;
               startBtn.setEnabled(false);
               stopBtn.setEnabled(true);
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                isReset = true;
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                isStopped = true;
                startBtn.setEnabled(true);
                stopBtn.setEnabled(false);
                redBtn.setBackgroundColor(Color.GRAY);
                yellowBtn.setBackgroundColor(Color.YELLOW);
                greenBtn.setBackgroundColor(Color.GRAY);
            }
        });


    }

    private void startTrafficLight()
    {
        Thread trafficLight = new Thread(new Runnable()
        {
            int light = 0;
            boolean toGreen = true;

            @Override
            public void run()
            {
                while(isStopped)
                {
                    try
                    {
                        Thread.sleep(10);
                    } catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }

                while(true)
                {
                    switch(light)
                    {
                        case 0:
                            CYCLE(0,3);
                            toGreen = true;
                            light++;
                            break;

                        case 1:
                            CYCLE(0,3);
                            if(toGreen)
                            {
                                light++;
                                toGreen = false;
                            }
                            else
                            {
                                light--;
                                toGreen = true;
                            }
                            break;

                        case 2:
                            CYCLE(0,3);
                            toGreen = false;
                            light--;
                            break;
                    }

                    runOnUiThread(new Runnable()
                    {
                        @Override
                        public void run()
                        {

                            if(isStopped)
                            {
                                light = 1;
                                redBtn.setBackgroundColor(Color.GRAY);
                                yellowBtn.setBackgroundColor(Color.YELLOW);
                                greenBtn.setBackgroundColor(Color.GRAY);
                            }

                            switch(light)
                            {
                                case 0:
                                    redBtn.setBackgroundColor(Color.RED);
                                    yellowBtn.setBackgroundColor(Color.GRAY);
                                    greenBtn.setBackgroundColor(Color.GRAY);
                                    break;
                                case 1:
                                    redBtn.setBackgroundColor(Color.GRAY);
                                    yellowBtn.setBackgroundColor(Color.YELLOW);
                                    greenBtn.setBackgroundColor(Color.GRAY);
                                    break;
                                case 2:
                                    redBtn.setBackgroundColor(Color.GRAY);
                                    yellowBtn.setBackgroundColor(Color.GRAY);
                                    greenBtn.setBackgroundColor(Color.GREEN);
                                    break;
                            }
                        }
                    });

                }
            }
        });

        trafficLight.start();
    }

    private void CYCLE(int min, int max)
    {
        for(int i = min; i < max; i++)
        {
            try
            {
                if(isStopped)
                    break;

                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    }

}
