package com.example.threadsapp;

import android.os.AsyncTask;
import android.widget.TextView;

public class AsyncTaskActivity extends AsyncTask
{

    private TextView m_taskFinishedTextView;

    public AsyncTaskActivity(TextView taskFinishedTextView)
    {
        m_taskFinishedTextView = taskFinishedTextView;
    }

    @Override
    protected Object doInBackground(Object[] objects)
    {

        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        m_taskFinishedTextView.setText("Task Finished");
        return null;
    }


}
