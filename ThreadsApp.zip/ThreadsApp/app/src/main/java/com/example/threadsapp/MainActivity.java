package com.example.threadsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    private Button simulateWorkBtn;
    private TextView taskFinishedTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        simulateWorkBtn = (Button) findViewById(R.id.simulateWorkBtn);
        taskFinishedTextView = (TextView) findViewById(R.id.taskFinishedTextView);

        taskFinishedTextView.setText("");

        simulateWorkBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                taskFinishedTextView.setText("");

                Intent gotoLogin = new Intent(getApplicationContext(), Login.class);
                startActivity(gotoLogin);

                AsyncTaskActivity oAsyncTask = new AsyncTaskActivity(taskFinishedTextView);
                oAsyncTask.doInBackground(null);

            }
        });

    }
}
