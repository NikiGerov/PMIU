package com.example.threadsapp;


public class LoginTask extends Login implements Runnable
{

    @Override
    public void run()
    {
        if(!LoginValidator())
        {
            resultTextView.setText("NOT VALID");
            return;
        }

        resultTextView.setText("VALID");

    }

    private boolean LoginValidator()
    {
        if(usernameEditText == null || passwordEditText == null ||
                usernameEditText.getText().toString().length() < 4 ||
                passwordEditText.getText().toString().length() < 4)
            return false;

        return true;

    }

}
